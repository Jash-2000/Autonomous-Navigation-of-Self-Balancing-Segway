# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

Contains code for Particle Swarm Optimization and Bacteria Foraging Optimization for MESFET DC parameter extraction.


### How do I get set up? ###

Download code and run files PSO###.m and BFO###.m.
You will need MATLAB to run these codes.

### Who do I talk to? ###

Rahul Kashyap
Email me at rahulkashyap7557@gmail.com